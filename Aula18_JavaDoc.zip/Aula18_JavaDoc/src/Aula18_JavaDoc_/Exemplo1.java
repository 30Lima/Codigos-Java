package Aula18_JavaDoc_;

/**
 * @author pedro
 * @since 03/10/2024
 * @version 1.0
 * @see *indicação para leitura de documentação*
 */

public class Exemplo1 {
	
	/**
	 * O atributo atr1 não serve para nada!
	 * private atributo atr1
	 */
	private int atr1;
	
	/**
	 * Este é o atributo 2 (atr2)
	 */
	private int atr2;
	
	/**
	 * Este é o atributo 3 (atr3)
	 * Olá, eu sou o atributo 3
	 */
	private int atr3;
	
	/**
	 * Construtor vazio!
	 */
	public Exemplo1() {
		
	}
	
	/**
	 * Construtor parametrizado com três atributos!
	 * @param atr1 - fornecido pelo usuário
	 * @param atr2 - fornecido pelo usuário
	 * @param atr3 - recebe o valor através de um arquivo
	 */
	
	public Exemplo1(int atr1, int atr2, int atr3){
		this.atr1 = atr1;
		this.atr2 = atr2;
		this.atr3 = atr3;
		
	}

	/**
	 * Atr1 é responsável por armazenar a informação do atributo 1
	 * @return the atr1
	 */
	public int getAtr1() {
		return atr1;
	}

	/**
	 * Atrq armazena informações sobre XPTO
	 * @param atr1 the atr1 to set
	 */
	public void setAtr1(int atr1) {
		this.atr1 = atr1;
	}

	/**
	 * Atr2 é responsável por armazenar a informação do atributo 2
	 * @return the atr2
	 */
	public int getAtr2() {
		return atr2;
	}

	/**
	 * Atr2 é o atributo que representa...
	 * @param atr2 the atr2 to set
	 */
	public void setAtr2(int atr2) {
		this.atr2 = atr2;
	}

	/**
	 * Atr3 é o atributo que recebe dados externos
	 * @return the atr3
	 */
	public int getAtr3() {
		return atr3;
	}

	/**
	 * Atr3 armazena dados sobre...
	 * @param atr3 the atr3 to set
	 */
	public void setAtr3(int atr3) {
		this.atr3 = atr3;
	}
	
	/*
	 * Método para realizar o cálculo do cubo de n,
	 * onde o n é um número inteiro
	 * @param n - é o valor que deve ser passado por parâmetro
	 * @return um número double que representa o cubo de um número 
	 * através do método Math.pw(n,3);
	 */
	
	
	public double calcularCubo(int n) {
		return Math.pow(n, 3);
	}
	
	//Testando JavaDoc
	
	public static void main(String[] args) {
		Exemplo1 exe1 = new Exemplo1();
		System.out.println("Resultado: " + exe1.calcularCubo(3));
	}
	
}




































